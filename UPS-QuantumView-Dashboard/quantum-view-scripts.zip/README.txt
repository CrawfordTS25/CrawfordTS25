UPS Quantum View - script pack
==============================

Open these in a plain-text editor (Notepad++, VS Code, Notepad) and copy from
there. Do NOT copy code out of the PDF: a PDF renders straight quotes as curly
quotes and hyphens as en-dashes, and both M and DAX reject them without telling
you that is what happened.

PASTE IN DESKTOP, IN THIS ORDER
  model-fixes-v2.pq            Steps 3 and 6   Power Query - the main fixes
  model-updates-v2.tmdl        Steps 5 and 7   TMDL - measures, relationships, Dim Date
  contacts-and-freshness.pq    Step 8          Branch_Contacts + Refresh Status
  contacts-and-freshness.tmdl  Step 8          the roster relationship + 9 measures

VERIFY  (View > DAX query view - all read-only, they change nothing)
  checks/3-age-days-anchor.dax
  checks/4-kpi-reconciliation.dax
  checks/5-status-vocabulary.dax
  checks/6-trace-notes-join.dax
  checks/7-classification-coverage.dax
  checks/8-dedupe-recency.dax
  checks/9-sources-and-contacts.dax

ALSO HERE
  UPS_Acct_Info_.xlsx          24 accounts, A25T52 added, range extended to A1:L25
  NEW-BUILD-FIXES.md           the instructions, in markdown
  WRITEBACK-AND-MAILMERGE.md   SharePoint list, Power Apps formulas, both flows
  PBIT-GUIDE.md                using a .pbit with a .pbix

Full step-by-step is in UPS_QuantumView_Build_Instructions.pdf.
