UPS QUANTUM VIEW - v3 script pack
=================================

NO .PBIX IN HERE, ON PURPOSE. Everything this round is model-layer. Your file
already opens and still has its sensitivity label - a label-stripped copy would
cost you the marking and gain you nothing. Keep working in
QuantumView_Checkpoint_DateSlicersPassed.pbix.

START WITH  docs/V3-RUNBOOK.md   9 steps, about 50 minutes.

THE ONE THING THAT IS BROKEN
----------------------------
    Current_Open_Trace[FA #]        I287748
    Trace_Contact_By_FA[FA #]        287748

Active relationship, matches 0 of 95. Every contact measure returns nothing
because of that one character. Strip the prefix and 66 of 66 FA-numbered traces
resolve - an FA email on all 66, a BOA cc on 61.

Reachable traces go from 0 via the roster to 90 of 95.

WHAT IS IN HERE
---------------
scripts/
    model-fixes-v3.pq          Steps 2,3,4  Power Query - archive source, the
                                            contact keys, home office map,
                                            notes list, send queue
    model-updates-v3.tmdl      Step 5       contact + coverage + mail merge
                                            measures, Dim Date
    qv-file-automation.ps1     Step 8       morning/afternoon sorting.
                                            Scheduling instructions are in the
                                            footer of the script itself.
    model-fixes-v2.pq          -            SECTION 10 IS STILL OUTSTANDING.
                                            The trace date columns are text, so
                                            no calendar can reach the trace side.

checks/                        Step 6       DAX query view, all read-only.
    10-contact-routing.dax                  the new one. Expect Contactable 90.
    (3 through 9 as before)

docs/
    V3-RUNBOOK.md                the guide
    QUERY-VALIDATION.md          all 14 queries and every relationship, measured
    TRACE-NOTES-AND-MAILMERGE.md the notes list, both flows, FA/BOA addressing
    CURRENT.md                   the entry point
    WRITEBACK-AND-MAILMERGE.md   the EXCEPTIONS-side write-back. Different list
                                 from the tracing notes - do not merge them.
    PBIT-GUIDE.md                using a .pbit with a .pbix

COPYING CODE
------------
Open these in Notepad++, VS Code or Notepad. If you ever copy M or DAX out of a
PDF, a straight quote becomes a curly quote and a hyphen becomes an en-dash, and
neither M nor DAX will tell you that is what went wrong.

TWO PLACES SHARE ONE NUMBER
---------------------------
The 13:30 morning/afternoon cutoff is hard-coded in BOTH qv-file-automation.ps1
and section 1 of model-fixes-v3.pq. Change one and you must change the other, or
the share and the dashboard will disagree about which run a file belongs to.
