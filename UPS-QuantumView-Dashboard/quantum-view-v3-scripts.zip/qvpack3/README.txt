UPS QUANTUM VIEW - v3 pack
==========================

NO .PBIX IN HERE, ON PURPOSE. Everything this round is model-layer. Your file
already opens and still has its sensitivity label - a stripped copy would cost
you the marking and gain you nothing. Keep working in
QuantumView_Checkpoint_DateSlicersPassed.pbix.

START WITH  UPS_QuantumView_v3_Instructions.pdf   10 pages, print it.
            docs/V3-RUNBOOK.md is the same content in markdown.
THEN        docs/PATHS.md   your path sheet vs what the queries actually read.

The v2 pack (UPS_QuantumView_Build_Instructions.pdf, NEW-BUILD-FIXES.md) is NOT
in this zip. It is superseded and both files now carry a banner saying so. Keep
them for the reasoning behind the exception classifier, the dedupe direction and
the account key derivation, but do not follow them as instructions.


THREE PATHS DISAGREE WITH THE MODEL
-----------------------------------
1. QV_RAW reads   ...\Administrative Services-Solutions\Quantum View\QV_Data
   Your sheet says ...\Administrative Services-Solutions\Power BI Reporting\
                      Report Data\QV_Data
   Different parent. If the old one still resolves you have two QV_Data folders
   and only one is being fed.

2. QV_RAW must point at Archive\, not QV_Data\. Folder.Files RECURSES, and
   QV_Data already holds Morning QV\, Afternoon QV\, Processed\ and Failed\.
   Pointed at QV_Data it reads every export once per folder and Total Shipments
   multiplies with nothing erroring.

3. Trace_Notes still reads the workbook while the notes live in
   Trace_Master_Streamlined_. That is the whole reason it returns 199 blank rows
   out of 200 and joins 1 of 95 traces.


ONE THING TO FIX BEFORE ROLLOUT
-------------------------------
The trace list is on a PERSONAL OneDrive:

    https://ejprod-my.sharepoint.com/personal/p258239_edwardjones_com/...
                    ^^^^^^^^^^^^^^^^^^^^^^^^^

That site is deprovisioned when that person leaves or changes roles, and Service
refresh has to run on their credentials - it CANNOT be moved to a service
account. Copy the list to a team site and change SiteUrl. Ten minutes, every
column name survives.


AND THE CONTACT JOIN
--------------------
    Current_Open_Trace[FA #]        I287748
    Trace_Contact_By_FA[FA #]        287748

Active relationship, matches 0 of 95. Strip the prefix and 66 of 66 FA-numbered
traces resolve. Reachable traces go from 0 via the roster to 90 of 95.


WHAT IS IN HERE
---------------
UPS_QuantumView_v3_Instructions.pdf     the guide, 10 pages

scripts/
    model-fixes-v3.pq          Steps 2,3,4  archive source, contact keys, home
                                            office map, notes list, send queue
    model-updates-v3.tmdl      Step 5       contact + coverage + mail merge
                                            measures, Dim Date
    qv-file-automation.ps1     Step 8       Archive -> Morning QV / Afternoon QV.
                                            Uses your Processed\ and Failed\
                                            folders. Scheduling notes are in the
                                            footer of the script.
    model-fixes-v2.pq          -            ONLY SECTION 10 IS STILL OUTSTANDING -
                                            trace date columns are text, so no
                                            calendar can reach the trace side.
                                            Do not re-run sections 1-9.

checks/                        Step 6       DAX query view, all read-only.
    10-contact-routing.dax                  the new one. Expect Contactable 90.

docs/
    V3-RUNBOOK.md                the guide in markdown
    PATHS.md                     every location, and the three that disagree
    QUERY-VALIDATION.md          all 14 queries and every relationship, measured
    TRACE-NOTES-AND-MAILMERGE.md the notes list, both flows, FA/BOA addressing
    CURRENT.md                   the entry point
    WRITEBACK-AND-MAILMERGE.md   the EXCEPTIONS-side write-back. Different list
                                 from the tracing notes - do not merge them.
    PBIT-GUIDE.md                using a .pbit with a .pbix


COPYING CODE
------------
Copy from the files in scripts/ and checks/, NEVER from the PDF. A PDF renders
straight quotes as curly quotes and hyphens as en-dashes, and neither M nor DAX
will tell you that is what went wrong.


TWO CONSTANTS LIVE IN TWO PLACES
--------------------------------
The 13:30 cutoff and the QV_Data root are hard-coded in BOTH
qv-file-automation.ps1 and section 1 of model-fixes-v3.pq. Change one and you
must change the other, or the share and the dashboard will disagree about which
run a file belongs to - and nothing will error.

USE UNC, NOT X:, in queries and scheduled tasks. Drive letters are per-logon-
session; the Service and an unattended task have none.
