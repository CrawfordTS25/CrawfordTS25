UPS QUANTUM VIEW - EXCEPTIONS & TRACING DASHBOARD
Complete deliverable pack


HANDLING
--------
This archive contains an UNCLASSIFIED COPY of a file marked
Internal Use Only - Standard. The sensitivity label was removed so the file
would open; step 11 of the instructions puts it back.

The .pbix carries real data: 92,630 manifest rows including ship-to names and
residential addresses, 56 distinct @edwardjones.com addresses, 69 FA numbers,
and the internal file server path. Several of the docs and scripts quote that
path too.

Store and share this archive the way you would the original file. Do not put it
in a public location. If you want the build in version control, export a .pbit
instead - a template carries the same model, report and measures with ZERO data
rows. See docs/PBIT-GUIDE.md.


START HERE
----------
UPS_QuantumView_Build_Instructions.pdf     21 pages. Print it, or put it on a
                                           second monitor with Power BI on the
                                           first. Everything is in here.

Two things before you open the .pbix:

  1. DO NOT click Apply on the pending Power Query change. It calls
     fnClassifyException, which does not exist anywhere in the model. Applying
     it fails the refresh and takes every downstream table with it. Step 3
     replaces it with a corrected version.

  2. The sensitivity label is removed. Step 11 puts it back. Do that before the
     file leaves your machine.


WHAT IS IN HERE
---------------
NEWQuantum_View_Exceptions_Dashboard_fixed.pbix
    The working file. Report layer repaired, label removed so it opens. The
    model inside is byte-identical to what you sent.

UPS_Acct_Info_.xlsx
    24 accounts. A25T52 added, table range already extended to A1:L25. Copy the
    new row into your live workbook at
    \\nfpgshare-1...\Report Data\UPS Acct Info .xlsx and extend the range there
    too, or the refresh will not see it.

scripts/          Paste these in Desktop, in this order:
    model-fixes-v2.pq             Steps 3 and 6   Power Query - the main fixes
    model-updates-v2.tmdl         Steps 5 and 7   TMDL - measures, relationships,
                                                  Dim Date
    contacts-and-freshness.pq     Step 8          Branch_Contacts + Refresh Status
    contacts-and-freshness.tmdl   Step 8          roster relationship + 9 measures

checks/           View > DAX query view. All read-only - they change nothing.
    3-age-days-anchor.dax           ageing measures case age, not run recency
    4-kpi-reconciliation.dax        Exception Rate 8.60%
    5-status-vocabulary.dax         the exact strings the status measures match
    6-trace-notes-join.dax          trace notes actually land
    7-classification-coverage.dax   nothing falls onto the dimension blank member
    8-dedupe-recency.dax            the queue shows current state
    9-sources-and-contacts.dax      the roster loaded, all five sources current

docs/
    CURRENT.md                   the entry point, in markdown
    NEW-BUILD-FIXES.md           the instructions - same content as the PDF
    WRITEBACK-AND-MAILMERGE.md   SharePoint list schema, Power Apps formulas,
                                 both flow definitions, blocked-tenant fallback
    PBIT-GUIDE.md                using a .pbit template with a .pbix
    MEASURE-SWEEP.md             all 25 measures audited, rate-grain reasoning,
                                 SharePoint vs API sourcing
    ACCOUNT-DRILLDOWN.md         why the account derives from the tracking
                                 number; the A25T52 decision
    RUNBOOK.md        SUPERSEDED the v5 Desktop guide, kept for reference
    BUILD_NOTES.md               layout and theme rationale from the first pass

tools/
    fix_new_dashboard.py         the report-layer pass, re-runnable against the
                                 original .pbix
    build_instructions_pdf.py    regenerates the PDF


COPYING CODE
------------
Copy from the files in scripts/ and checks/, NEVER from the PDF. A PDF renders
straight quotes as curly quotes and hyphens as en-dashes. M and DAX both reject
those, and the error message will not tell you that is what happened.

Open them in Notepad++, VS Code, or plain Notepad.


DO NOT RUN THE V5 SCRIPTS AND THESE
-----------------------------------
An earlier generation - model-updates.tmdl and model-fixes.pq - exists in the
git history. model-updates-v2.tmdl and model-fixes-v2.pq supersede them
entirely. Running both would apply the same changes twice and, in the case of
the account key columns, collide. Only the v2 scripts are in this archive, so
just use what is here.


TIME BUDGET
-----------
Twelve Desktop steps, about 55 minutes end to end. Steps 1-5 are the ones that
matter; 6-12 are completion and publish. Keep a copy of the .pbix before you
start - every step is reversible, but a known-good starting point costs nothing.
